<img src="https://i.hizliresim.com/h2uyn65.png" width="300" height="300">


Telegramda Eğlence Amaçlı Grublarınızda DC Oyun Botuyum

# Heroku'da Clonlamak

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/SakirBey1/dcbot)

#

Bağış Yapmak İçin [TIKLA](https://telegra.ph/Ba%C4%9F%C4%B1%C5%9F-04-29)
